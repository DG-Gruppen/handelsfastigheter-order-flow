import { CategoryColor } from '../types';

export function readTime(content: string): string {
  const words = content.replace(/<[^>]+>/g, '').split(/\s+/).length;
  const mins = Math.max(1, Math.round(words / 200));
  return `${mins} min läsning`;
}

export function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins} min sedan`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} tim sedan`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} dag${days !== 1 ? 'ar' : ''} sedan`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks} vecka${weeks !== 1 ? 'r' : ''} sedan`;
  const months = Math.floor(days / 30);
  return `${months} månad${months !== 1 ? 'er' : ''} sedan`;
}

export function slugId(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function fuzzySearch<T extends { title: string; excerpt?: string; tags?: string[] }>(
  items: T[],
  query: string
): T[] {
  if (!query.trim()) return items;
  const q = query.toLowerCase();
  return items.filter(item =>
    item.title.toLowerCase().includes(q) ||
    (item.excerpt?.toLowerCase().includes(q)) ||
    (item.tags?.some(t => t.toLowerCase().includes(q)))
  );
}

export const COLOR_MAP: Record<CategoryColor, { bg: string; text: string; badge: string; badgeText: string; border: string }> = {
  blue: {
    bg: 'bg-blue-50',
    text: 'text-blue-800',
    badge: 'bg-blue-100',
    badgeText: 'text-blue-800',
    border: 'border-blue-200',
  },
  green: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    badge: 'bg-emerald-100',
    badgeText: 'text-emerald-800',
    border: 'border-emerald-200',
  },
  amber: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    badge: 'bg-amber-100',
    badgeText: 'text-amber-800',
    border: 'border-amber-200',
  },
  red: {
    bg: 'bg-red-50',
    text: 'text-red-800',
    badge: 'bg-red-100',
    badgeText: 'text-red-800',
    border: 'border-red-200',
  },
  purple: {
    bg: 'bg-purple-50',
    text: 'text-purple-800',
    badge: 'bg-purple-100',
    badgeText: 'text-purple-800',
    border: 'border-purple-200',
  },
  teal: {
    bg: 'bg-teal-50',
    text: 'text-teal-800',
    badge: 'bg-teal-100',
    badgeText: 'text-teal-800',
    border: 'border-teal-200',
  },
  pink: {
    bg: 'bg-pink-50',
    text: 'text-pink-800',
    badge: 'bg-pink-100',
    badgeText: 'text-pink-800',
    border: 'border-pink-200',
  },
};

export function getYouTubeEmbedId(url: string): string | null {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
}

export function getVimeoEmbedId(url: string): string | null {
  const match = url.match(/vimeo\.com\/(\d+)/);
  return match ? match[1] : null;
}
