import { useState, useEffect, useRef } from 'react';
import { useApp } from '../../store/AppContext';
import CategoryBadge from '../ui/CategoryBadge';

export default function SearchPalette() {
  const { state, dispatch, getCategoryById } = useApp();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const results = query.trim().length > 1
    ? state.articles.filter(a =>
        a.title.toLowerCase().includes(query.toLowerCase()) ||
        a.excerpt.toLowerCase().includes(query.toLowerCase()) ||
        a.tags.some(t => t.toLowerCase().includes(query.toLowerCase()))
      ).slice(0, 8)
    : [];

  const videoResults = query.trim().length > 1
    ? state.videos.filter(v =>
        v.title.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 3)
    : [];

  useEffect(() => {
    if (state.searchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
    }
  }, [state.searchOpen]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        dispatch({ type: 'SET_SEARCH_OPEN', open: true });
      }
      if (e.key === 'Escape') {
        dispatch({ type: 'SET_SEARCH_OPEN', open: false });
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [dispatch]);

  if (!state.searchOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/40 z-50 flex items-start justify-center pt-20 px-4"
      onClick={(e) => { if (e.target === e.currentTarget) dispatch({ type: 'SET_SEARCH_OPEN', open: false }); }}
    >
      <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-gray-100">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <input
            ref={inputRef}
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Sök artiklar, videos, taggar..."
            className="flex-1 text-sm text-gray-900 placeholder-gray-400 outline-none bg-transparent"
          />
          <kbd
            onClick={() => dispatch({ type: 'SET_SEARCH_OPEN', open: false })}
            className="text-xs text-gray-400 border border-gray-200 rounded px-1.5 py-0.5 cursor-pointer hover:bg-gray-50"
          >
            ESC
          </kbd>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto py-2">
          {query.trim().length < 2 && (
            <div className="px-4 py-6 text-center text-sm text-gray-400">
              Börja skriva för att söka...
            </div>
          )}

          {results.length > 0 && (
            <>
              <div className="px-4 py-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider">Artiklar</div>
              {results.map(article => {
                const cat = getCategoryById(article.categoryId);
                return (
                  <button
                    key={article.id}
                    onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: article.id })}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 transition-colors text-left"
                  >
                    <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center text-sm flex-shrink-0">
                      📄
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-gray-900 truncate">{article.title}</div>
                      <div className="text-xs text-gray-400 truncate">{article.excerpt}</div>
                    </div>
                    {cat && <CategoryBadge category={cat} />}
                  </button>
                );
              })}
            </>
          )}

          {videoResults.length > 0 && (
            <>
              <div className="px-4 py-1.5 text-xs font-medium text-gray-400 uppercase tracking-wider mt-1">Videos</div>
              {videoResults.map(video => (
                <button
                  key={video.id}
                  onClick={() => dispatch({ type: 'NAVIGATE', page: 'videos' })}
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center text-sm flex-shrink-0">
                    🎬
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 truncate">{video.title}</div>
                    <div className="text-xs text-gray-400">{video.duration} · {video.level}</div>
                  </div>
                  <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">Video</span>
                </button>
              ))}
            </>
          )}

          {query.trim().length >= 2 && results.length === 0 && videoResults.length === 0 && (
            <div className="px-4 py-6 text-center text-sm text-gray-400">
              Inga resultat för "{query}"
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
