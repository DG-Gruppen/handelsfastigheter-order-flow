import { useEffect } from 'react';

interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'info';
  onClose: () => void;
}

export default function Toast({ message, type = 'success', onClose }: ToastProps) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000);
    return () => clearTimeout(t);
  }, [onClose]);

  const colors = {
    success: 'text-emerald-700',
    error: 'text-red-600',
    info: 'text-blue-700',
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 bg-white border border-gray-200 rounded-xl px-4 py-3 shadow-lg text-sm animate-in fade-in slide-in-from-bottom-2">
      <span className={colors[type]}>
        {type === 'success' ? '✓' : type === 'error' ? '✕' : 'i'}
      </span>
      <span className="text-gray-800">{message}</span>
      <button onClick={onClose} className="ml-2 text-gray-400 hover:text-gray-600">✕</button>
    </div>
  );
}
