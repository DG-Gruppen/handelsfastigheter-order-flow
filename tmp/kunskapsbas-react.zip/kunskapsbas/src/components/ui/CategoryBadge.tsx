import { Category } from '../../types';
import { COLOR_MAP } from '../../utils';

interface Props {
  category: Category;
  size?: 'sm' | 'md';
}

export default function CategoryBadge({ category, size = 'sm' }: Props) {
  const colors = COLOR_MAP[category.color];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-medium ${
        size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-2.5 py-1'
      } ${colors.badge} ${colors.badgeText}`}
    >
      <span>{category.icon}</span>
      {category.name}
    </span>
  );
}
