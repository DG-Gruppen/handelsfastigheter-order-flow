import { useApp } from '../../store/AppContext';
import { Page } from '../../types';

const PAGE_LABELS: Record<Page, string> = {
  home: 'Hem',
  categories: 'Kategorier',
  article: 'Artikel',
  'article-edit': 'Redigera artikel',
  'article-new': 'Ny artikel',
  videos: 'Videoutbildningar',
  starred: 'Stjärnmärkta',
  admin: 'Admin',
};

export default function TopBar() {
  const { state, dispatch, getArticleById } = useApp();
  const { currentPage, currentArticleId } = state;

  const article = currentArticleId ? getArticleById(currentArticleId) : null;

  return (
    <header className="h-12 bg-white border-b border-gray-100 flex items-center px-6 gap-3 flex-shrink-0">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-sm flex-1 min-w-0">
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', page: 'home' })}
          className="text-gray-400 hover:text-gray-700 transition-colors flex-shrink-0"
        >
          Hem
        </button>
        {currentPage !== 'home' && (
          <>
            <span className="text-gray-300">/</span>
            {currentPage === 'article' && article ? (
              <>
                <button
                  onClick={() => dispatch({ type: 'NAVIGATE', page: 'categories' })}
                  className="text-gray-400 hover:text-gray-700 transition-colors truncate max-w-[120px]"
                >
                  Kategorier
                </button>
                <span className="text-gray-300">/</span>
                <span className="text-gray-800 font-medium truncate max-w-[200px]">{article.title}</span>
              </>
            ) : (
              <span className="text-gray-800 font-medium">{PAGE_LABELS[currentPage]}</span>
            )}
          </>
        )}
      </nav>

      {/* Actions */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          onClick={() => dispatch({ type: 'SET_SEARCH_OPEN', open: true })}
          className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-800 px-2.5 py-1.5 rounded-lg hover:bg-gray-50 transition-colors border border-gray-200"
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
          </svg>
          <span>Sök</span>
          <kbd className="text-xs text-gray-400 font-mono">⌘K</kbd>
        </button>
        <button
          onClick={() => dispatch({ type: 'NAVIGATE', page: 'article-new' })}
          className="flex items-center gap-1.5 text-sm bg-gray-900 text-white px-3 py-1.5 rounded-lg hover:bg-gray-700 transition-colors"
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 5v14M5 12h14" />
          </svg>
          Ny artikel
        </button>
      </div>
    </header>
  );
}
