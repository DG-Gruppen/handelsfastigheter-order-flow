import { useApp } from '../../store/AppContext';
import { COLOR_MAP } from '../../utils';
import { Page } from '../../types';

export default function Sidebar() {
  const { state, dispatch, currentUser } = useApp();
  const { currentPage, categories, articles, sidebarOpen } = state;

  const navItem = (page: Page, icon: React.ReactNode, label: string) => {
    const active = currentPage === page || (page === 'article' && currentPage === 'article');
    return (
      <button
        onClick={() => dispatch({ type: 'NAVIGATE', page })}
        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
          active
            ? 'bg-gray-100 text-gray-900 font-medium'
            : 'text-gray-500 hover:bg-gray-50 hover:text-gray-800'
        }`}
      >
        <span className="w-4 h-4 flex-shrink-0">{icon}</span>
        {sidebarOpen && <span>{label}</span>}
      </button>
    );
  };

  return (
    <aside
      className={`${sidebarOpen ? 'w-64' : 'w-14'} flex-shrink-0 bg-white border-r border-gray-100 flex flex-col transition-all duration-200 overflow-hidden`}
      style={{ minHeight: '100vh' }}
    >
      {/* Header */}
      <div className="p-4 border-b border-gray-100 flex items-center gap-2.5">
        <div className="w-7 h-7 bg-gray-900 rounded-md flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
          K
        </div>
        {sidebarOpen && <span className="font-semibold text-gray-900 text-sm">Kunskapsbas</span>}
        {sidebarOpen && (
          <button
            onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
            className="ml-auto text-gray-400 hover:text-gray-600 p-1 rounded"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="m15 18-6-6 6-6" />
            </svg>
          </button>
        )}
        {!sidebarOpen && (
          <button
            onClick={() => dispatch({ type: 'TOGGLE_SIDEBAR' })}
            className="text-gray-400 hover:text-gray-600 p-1 rounded"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="m9 18 6-6-6-6" />
            </svg>
          </button>
        )}
      </div>

      {/* Search trigger */}
      {sidebarOpen && (
        <div className="px-3 py-2">
          <button
            onClick={() => dispatch({ type: 'SET_SEARCH_OPEN', open: true })}
            className="w-full flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-400 hover:border-gray-300 transition-colors"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" />
            </svg>
            <span className="flex-1 text-left">Sök...</span>
            <kbd className="text-xs bg-white border border-gray-200 rounded px-1.5 py-0.5 font-mono">⌘K</kbd>
          </button>
        </div>
      )}

      {/* Nav */}
      <nav className="p-2 flex-1 overflow-y-auto space-y-0.5">
        {navItem('home',
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><polyline points="9 22 9 12 15 12 15 22" /></svg>,
          'Hem'
        )}
        {navItem('categories',
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="7" height="7" x="3" y="3" rx="1" /><rect width="7" height="7" x="14" y="3" rx="1" /><rect width="7" height="7" x="14" y="14" rx="1" /><rect width="7" height="7" x="3" y="14" rx="1" /></svg>,
          'Kategorier'
        )}
        {navItem('videos',
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="23 7 16 12 23 17 23 7" /><rect width="15" height="14" x="1" y="5" rx="2" /></svg>,
          'Videoutbildningar'
        )}
        {navItem('starred',
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>,
          'Stjärnmärkta'
        )}

        {sidebarOpen && (
          <>
            <div className="pt-3 pb-1 px-3">
              <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">Kategorier</span>
            </div>
            {categories.map(cat => {
              const colors = COLOR_MAP[cat.color];
              const count = articles.filter(a => a.categoryId === cat.id && a.status === 'published').length;
              return (
                <button
                  key={cat.id}
                  onClick={() => dispatch({ type: 'NAVIGATE', page: 'categories' })}
                  className="w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm text-gray-500 hover:bg-gray-50 hover:text-gray-800 transition-colors"
                >
                  <span>{cat.icon}</span>
                  <span className="flex-1 text-left truncate">{cat.name}</span>
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${colors.badge} ${colors.badgeText}`}>{count}</span>
                </button>
              );
            })}

            <div className="pt-3">
              <button
                onClick={() => dispatch({ type: 'NAVIGATE', page: 'article-new' })}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-gray-500 hover:bg-gray-50 hover:text-gray-800 transition-colors"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><path d="M12 8v8M8 12h8" /></svg>
                Ny artikel
              </button>
            </div>
          </>
        )}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-gray-100">
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-medium flex-shrink-0"
            style={{ background: currentUser.avatarColor }}
          >
            {currentUser.initials}
          </div>
          {sidebarOpen && (
            <div className="min-w-0">
              <div className="text-xs font-medium text-gray-800 truncate">{currentUser.name}</div>
              <div className="text-xs text-gray-400 truncate">{currentUser.role}</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
