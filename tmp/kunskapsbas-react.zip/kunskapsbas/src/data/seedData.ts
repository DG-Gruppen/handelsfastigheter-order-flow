import { Article, Category, User, VideoLesson } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'it',
    name: 'IT & System',
    icon: '💻',
    description: 'Serverhantering, deployment, nätverk och teknisk dokumentation.',
    color: 'blue',
    parentId: null,
  },
  {
    id: 'hr',
    name: 'HR & Personal',
    icon: '👥',
    description: 'Onboarding, policyer, förmåner och arbetsrättsliga riktlinjer.',
    color: 'green',
    parentId: null,
  },
  {
    id: 'rutiner',
    name: 'Rutiner & Processer',
    icon: '📋',
    description: 'Arbetsflöden, checklistor och standardrutiner.',
    color: 'amber',
    parentId: null,
  },
  {
    id: 'sakerhet',
    name: 'Säkerhet & Compliance',
    icon: '🛡️',
    description: 'GDPR, informationssäkerhet och incidenthantering.',
    color: 'red',
    parentId: null,
  },
  {
    id: 'produkter',
    name: 'Produkter & Tjänster',
    icon: '📦',
    description: 'Produktöversikter, prislistor och kundavtal.',
    color: 'purple',
    parentId: null,
  },
];

export const USERS: User[] = [
  { id: 'anna', name: 'Admin Anna', initials: 'AA', email: 'anna@foretaget.se', role: 'admin', avatarColor: '#1E3A8A' },
  { id: 'erik', name: 'Editor Erik', initials: 'EE', email: 'erik@foretaget.se', role: 'editor', avatarColor: '#065F46' },
  { id: 'vera', name: 'Viewer Vera', initials: 'VV', email: 'vera@foretaget.se', role: 'viewer', avatarColor: '#6B7280' },
];

export const ARTICLES: Article[] = [
  {
    id: 'onboarding',
    title: 'Onboarding — Kom igång som ny medarbetare',
    excerpt: 'Allt du behöver veta under din första vecka: system, rutiner, kontakter och praktisk information.',
    content: `<h2>Välkommen till teamet!</h2>
<p>Den här guiden hjälper dig komma igång snabbt och smidigt under din första vecka hos oss. Här hittar du allt från systemåtkomst till var kaffemaskinen finns.</p>
<h2>Dag 1 — Det viktigaste</h2>
<ul>
<li>Hämta din dator från IT (plan 3, rum 312)</li>
<li>Logga in på e-post med dina tillfälliga uppgifter</li>
<li>Boka möte med din mentor inom de första 2 dagarna</li>
<li>Läs igenom våra interna riktlinjer</li>
</ul>
<h2>System du behöver tillgång till</h2>
<p>Kontakta IT-support (<code>it@foretaget.se</code>) för följande åtkomster:</p>
<ul>
<li>Intranät och kunskapsbas</li>
<li>Projekthanteringssystemet</li>
<li>VPN för distansarbete</li>
<li>Tidrapporteringssystemet</li>
</ul>
<h2>Viktiga kontakter</h2>
<blockquote>Vid frågor om HR och lön, kontakta personalavdelningen på ext. 200. För IT-problem, ring IT-support på ext. 100 eller skicka e-post till it@foretaget.se</blockquote>
<h2>Arbetsplatspolicyer</h2>
<p>Ta dig tid att läsa igenom policyer för arbetsmiljö, informationssäkerhet och uppförandekod. Alla finns under Säkerhet & Compliance.</p>`,
    categoryId: 'hr',
    tags: ['Onboarding', 'HR', 'Välkommen', 'Rutiner'],
    authorId: 'anna',
    status: 'published',
    pinned: true,
    createdAt: '2026-03-10T09:00:00Z',
    updatedAt: '2026-03-13T14:00:00Z',
    viewCount: 342,
  },
  {
    id: 'gdpr',
    title: 'GDPR & Dataskydd — Riktlinjer för personuppgifter',
    excerpt: 'Hur vi hanterar personuppgifter, vad som är tillåtet och vad vi aldrig får göra enligt GDPR.',
    content: `<h2>Vad är GDPR?</h2>
<p>GDPR (General Data Protection Regulation) är EU:s dataskyddslagstiftning som reglerar hur vi hanterar personuppgifter. Alla medarbetare är skyldiga att följa dessa regler.</p>
<h2>Vad räknas som personuppgifter?</h2>
<ul>
<li>Namn, adress, e-postadress, telefonnummer</li>
<li>Personnummer och liknande identifikatorer</li>
<li>IP-adresser och cookie-data</li>
<li>Hälsoinformation och biometrisk data</li>
</ul>
<h2>Det här får vi ALDRIG göra</h2>
<blockquote>Dela kunduppgifter med tredje part utan samtycke. Spara personuppgifter längre än nödvändigt. Skicka okrypterade känsliga uppgifter via e-post.</blockquote>
<h2>Vid en dataintrång</h2>
<p>Kontakta omedelbart IT-säkerhet och DPO. Vi är skyldiga att rapportera till IMY inom 72 timmar.</p>
<pre><code>Kontakt DPO: dpo@foretaget.se
Telefon: ext. 150 (tillgänglig 24/7 vid incident)</code></pre>`,
    categoryId: 'sakerhet',
    tags: ['GDPR', 'Dataskydd', 'Compliance', 'Obligatorisk'],
    authorId: 'anna',
    status: 'published',
    pinned: true,
    createdAt: '2026-03-05T10:00:00Z',
    updatedAt: '2026-03-09T11:00:00Z',
    viewCount: 589,
  },
  {
    id: 'deploy',
    title: 'Driftsättning — Steg-för-steg guide',
    excerpt: 'Hur vi deployer applikationer till produktion med Docker, Nginx och Certbot.',
    content: `<h2>Översikt</h2>
<p>Den här guiden beskriver hur vi deployer applikationer till vår produktionsmiljö med Docker, Nginx som reverse proxy och Certbot för SSL-certifikat.</p>
<h2>Förberedelser</h2>
<ul>
<li>SSH-åtkomst till produktionsservern</li>
<li>Docker och Docker Compose installerade</li>
<li>DNS-post som pekar mot serverns IP</li>
<li>Koden testad och godkänd i staging</li>
</ul>
<h2>Steg 1 — Bygg Docker-imagen</h2>
<pre><code>docker build -t appnamn:latest .
docker tag appnamn:latest registry.foretaget.se/appnamn:latest
docker push registry.foretaget.se/appnamn:latest</code></pre>
<h2>Steg 2 — Uppdatera produktionsservern</h2>
<pre><code>ssh deploy@prod.foretaget.se
cd /opt/appnamn
docker-compose pull
docker-compose up -d --remove-orphans</code></pre>
<h2>Rollback</h2>
<blockquote>Om något går fel, kör omedelbart rollback. Notera alltid versionstaggen från föregående deployment.</blockquote>
<pre><code>docker-compose down
docker tag registry.foretaget.se/appnamn:previous appnamn:latest
docker-compose up -d</code></pre>`,
    categoryId: 'it',
    tags: ['Docker', 'Nginx', 'Deploy', 'Certbot', 'DevOps'],
    authorId: 'anna',
    status: 'published',
    pinned: true,
    createdAt: '2026-03-01T08:00:00Z',
    updatedAt: '2026-03-14T16:00:00Z',
    viewCount: 211,
  },
  {
    id: 'losenord',
    title: 'Lösenordspolicy och MFA',
    excerpt: 'Krav på lösenordsstyrka, hantering av autentisering och obligatorisk MFA för alla konton.',
    content: `<h2>Lösenordskrav</h2>
<p>Alla konton ska använda lösenord som uppfyller följande minimikrav:</p>
<ul>
<li>Minst 12 tecken</li>
<li>Kombination av stora och små bokstäver, siffror och specialtecken</li>
<li>Får inte återanvändas från de 10 senaste lösenorden</li>
<li>Byts ut minst var 180:e dag för känsliga system</li>
</ul>
<h2>Multifaktorautentisering (MFA)</h2>
<p>MFA är obligatoriskt för alla medarbetare på följande system: VPN, e-post, HR-system och alla administrativa gränssnitt.</p>
<pre><code># Aktivera MFA via Google Authenticator
1. Ladda ner Google Authenticator
2. Gå till Inställningar > Säkerhet > MFA
3. Skanna QR-koden
4. Bekräfta med engångskod</code></pre>`,
    categoryId: 'sakerhet',
    tags: ['Säkerhet', 'MFA', 'Lösenord', 'Autentisering'],
    authorId: 'erik',
    status: 'published',
    pinned: false,
    createdAt: '2026-02-20T09:00:00Z',
    updatedAt: '2026-03-01T10:00:00Z',
    viewCount: 178,
  },
  {
    id: 'semester',
    title: 'Semesterpolicy och ledighetsansökan',
    excerpt: 'Hur du ansöker om semester, regler för semesterdagar och vad som gäller vid VAB.',
    content: `<h2>Semesterdagar</h2>
<p>Alla medarbetare har rätt till 25 semesterdagar per år enligt Semesterlagen. Nyanställda tjänar in semester från anställningens start.</p>
<h2>Så ansöker du om semester</h2>
<ol>
<li>Logga in i HR-systemet</li>
<li>Välj "Ledighetsansökan"</li>
<li>Ange datum och typ av ledighet</li>
<li>Din chef godkänner eller avslår inom 5 arbetsdagar</li>
</ol>
<h2>VAB och föräldraledighet</h2>
<p>Meddela din chef så tidigt som möjligt. Ansökan om föräldraledighet ska lämnas in minst 2 månader i förväg.</p>`,
    categoryId: 'hr',
    tags: ['Semester', 'Ledighet', 'HR', 'VAB'],
    authorId: 'anna',
    status: 'published',
    pinned: false,
    createdAt: '2026-01-15T10:00:00Z',
    updatedAt: '2026-02-01T09:00:00Z',
    viewCount: 267,
  },
  {
    id: 'faktura',
    title: 'Faktureringsprocess — Steg-för-steg',
    excerpt: 'Hur vi skapar, skickar och följer upp fakturor till kunder.',
    content: `<h2>Faktureringsflödet</h2>
<p>Alla fakturor ska skapas i affärssystemet och godkännas av projektansvarig innan de skickas till kund.</p>
<h2>Steg 1 — Skapa faktura</h2>
<ul>
<li>Logga in i affärssystemet</li>
<li>Välj kund och projekt</li>
<li>Lägg till timmar/artiklar enligt offert</li>
<li>Kontrollera moms och betalningsvillkor</li>
</ul>
<h2>Betalningsvillkor</h2>
<blockquote>Standard är 30 dagars netto. För nya kunder gäller 14 dagars netto tills kreditgräns är etablerad.</blockquote>`,
    categoryId: 'rutiner',
    tags: ['Faktura', 'Ekonomi', 'Process', 'Kund'],
    authorId: 'erik',
    status: 'published',
    pinned: false,
    createdAt: '2026-01-20T08:00:00Z',
    updatedAt: '2026-02-10T14:00:00Z',
    viewCount: 134,
  },
  {
    id: 'hyper-v',
    title: 'Hyper-V och VM-hantering',
    excerpt: 'Skapa, konfigurera och hantera virtuella maskiner i vår Hyper-V-miljö.',
    content: `<h2>Vår VM-infrastruktur</h2>
<p>Vi kör en tre-nivå Hyper-V-miljö med separata VM:ar för Frontend, Backend och Databas. Alla VM:ar kör Ubuntu LTS.</p>
<h2>Skapa en ny VM</h2>
<pre><code># Via Hyper-V Manager
1. Öppna Hyper-V Manager
2. Åtgärd > Ny > Virtuell dator
3. Välj Generation 2
4. Tilldela minst 2 GB RAM (dynamiskt)
5. Skapa ny virtuell hårddisk (min 20 GB)</code></pre>
<h2>Nätverkskonfiguration</h2>
<p>Varje VM ska ha två nätverkskort: ett externt (internet) och ett internt (kommunikation mellan VM:ar). Kontrollera alltid att eth1 är korrekt konfigurerat i /etc/netplan/.</p>`,
    categoryId: 'it',
    tags: ['Hyper-V', 'VM', 'Infrastruktur', 'Ubuntu'],
    authorId: 'anna',
    status: 'published',
    pinned: false,
    createdAt: '2026-03-12T11:00:00Z',
    updatedAt: '2026-03-15T09:00:00Z',
    viewCount: 89,
  },
  {
    id: 'produktportfolj',
    title: 'Produktportfölj 2026',
    excerpt: 'Översikt över alla produkter och tjänster vi erbjuder kunder detta år.',
    content: `<h2>Tjänsteöversikt</h2>
<p>Vi erbjuder ett brett utbud av IT-konsulttjänster och produkter anpassade för SME-segmentet.</p>
<h2>Konsulttjänster</h2>
<ul>
<li>IT-infrastruktur och serverhantering</li>
<li>Systemutveckling (webb och API)</li>
<li>IT-säkerhetsrevision</li>
<li>GDPR-rådgivning och compliance</li>
</ul>
<h2>Produkter</h2>
<ul>
<li>Dokumentationsplattform (SaaS)</li>
<li>Kundportal med ärendehantering</li>
<li>Backup-lösning (lokal + molnet)</li>
</ul>`,
    categoryId: 'produkter',
    tags: ['Produkter', 'Tjänster', 'Portfölj', 'Försäljning'],
    authorId: 'anna',
    status: 'published',
    pinned: false,
    createdAt: '2026-01-05T09:00:00Z',
    updatedAt: '2026-01-10T14:00:00Z',
    viewCount: 156,
  },
];

export const VIDEO_LESSONS: VideoLesson[] = [
  {
    id: 'intro-system',
    title: 'Introduktionskurs — Systemöversikt',
    description: 'Täcker hela systemarkitekturen. Perfekt för nya medarbetare och konsulter.',
    categoryId: 'it',
    url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnailColor: 'linear-gradient(135deg, #1E3A8A 0%, #3B82F6 100%)',
    duration: '22:14',
    level: 'Grundnivå',
    viewCount: 1234,
    createdAt: '2026-02-01T10:00:00Z',
    authorId: 'anna',
  },
  {
    id: 'docker-intro',
    title: 'Docker för nybörjare — Steg-för-steg',
    description: 'Lär dig grunderna i Docker: images, containers, compose och networking.',
    categoryId: 'it',
    url: 'https://www.youtube.com/watch?v=fqMOX6JJhGo',
    thumbnailColor: 'linear-gradient(135deg, #0F766E 0%, #14B8A6 100%)',
    duration: '35:07',
    level: 'Mellannivå',
    viewCount: 876,
    createdAt: '2026-02-15T10:00:00Z',
    authorId: 'erik',
  },
  {
    id: 'gdpr-utbildning',
    title: 'GDPR i praktiken — Obligatorisk utbildning',
    description: 'Obligatorisk utbildning för alla medarbetare om dataskydd och GDPR.',
    categoryId: 'sakerhet',
    url: 'https://www.youtube.com/watch?v=9Deg7VrpHbM',
    thumbnailColor: 'linear-gradient(135deg, #991B1B 0%, #EF4444 100%)',
    duration: '18:45',
    level: 'Alla nivåer',
    viewCount: 2089,
    createdAt: '2026-01-10T10:00:00Z',
    authorId: 'anna',
  },
];

export const STARRED_IDS_DEFAULT = ['gdpr', 'deploy'];
