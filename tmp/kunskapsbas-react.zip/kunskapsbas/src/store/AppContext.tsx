import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { Article, Category, User, VideoLesson, Page } from '../types';
import { ARTICLES, CATEGORIES, USERS, VIDEO_LESSONS, STARRED_IDS_DEFAULT } from '../data/seedData';

interface AppState {
  articles: Article[];
  categories: Category[];
  users: User[];
  videos: VideoLesson[];
  currentUserId: string;
  starredIds: string[];
  recentIds: string[];
  currentPage: Page;
  currentArticleId: string | null;
  sidebarOpen: boolean;
  searchOpen: boolean;
}

type Action =
  | { type: 'NAVIGATE'; page: Page; articleId?: string }
  | { type: 'TOGGLE_STAR'; id: string }
  | { type: 'ADD_ARTICLE'; article: Article }
  | { type: 'UPDATE_ARTICLE'; article: Article }
  | { type: 'DELETE_ARTICLE'; id: string }
  | { type: 'ADD_VIDEO'; video: VideoLesson }
  | { type: 'DELETE_VIDEO'; id: string }
  | { type: 'SET_SEARCH_OPEN'; open: boolean }
  | { type: 'TOGGLE_SIDEBAR' }
  | { type: 'VIEW_ARTICLE'; id: string };

function loadState(): Partial<AppState> {
  try {
    const raw = localStorage.getItem('kunskapsbas_state');
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveState(state: AppState) {
  try {
    localStorage.setItem('kunskapsbas_state', JSON.stringify({
      articles: state.articles.filter(a => !ARTICLES.find(s => s.id === a.id)),
      starredIds: state.starredIds,
      recentIds: state.recentIds,
      videos: state.videos.filter(v => !VIDEO_LESSONS.find(s => s.id === v.id)),
    }));
  } catch {}
}

function buildInitialState(): AppState {
  const saved = loadState();
  const savedArticles = (saved.articles as Article[]) || [];
  const savedVideos = (saved.videos as VideoLesson[]) || [];
  return {
    articles: [...ARTICLES, ...savedArticles],
    categories: CATEGORIES,
    users: USERS,
    videos: [...VIDEO_LESSONS, ...savedVideos],
    currentUserId: 'anna',
    starredIds: (saved.starredIds as string[]) || STARRED_IDS_DEFAULT,
    recentIds: (saved.recentIds as string[]) || [],
    currentPage: 'home',
    currentArticleId: null,
    sidebarOpen: true,
    searchOpen: false,
  };
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'NAVIGATE':
      return { ...state, currentPage: action.page, currentArticleId: action.articleId ?? state.currentArticleId, searchOpen: false };
    case 'VIEW_ARTICLE': {
      const recent = [action.id, ...state.recentIds.filter(id => id !== action.id)].slice(0, 10);
      return { ...state, currentPage: 'article', currentArticleId: action.id, recentIds: recent, searchOpen: false };
    }
    case 'TOGGLE_STAR': {
      const already = state.starredIds.includes(action.id);
      return { ...state, starredIds: already ? state.starredIds.filter(id => id !== action.id) : [...state.starredIds, action.id] };
    }
    case 'ADD_ARTICLE':
      return { ...state, articles: [...state.articles, action.article] };
    case 'UPDATE_ARTICLE':
      return { ...state, articles: state.articles.map(a => a.id === action.article.id ? action.article : a) };
    case 'DELETE_ARTICLE':
      return { ...state, articles: state.articles.filter(a => a.id !== action.id), starredIds: state.starredIds.filter(id => id !== action.id) };
    case 'ADD_VIDEO':
      return { ...state, videos: [...state.videos, action.video] };
    case 'DELETE_VIDEO':
      return { ...state, videos: state.videos.filter(v => v.id !== action.id) };
    case 'SET_SEARCH_OPEN':
      return { ...state, searchOpen: action.open };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarOpen: !state.sidebarOpen };
    default:
      return state;
  }
}

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  getCategoryById: (id: string) => Category | undefined;
  getUserById: (id: string) => User | undefined;
  getArticleById: (id: string) => Article | undefined;
  currentUser: User;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, buildInitialState);

  useEffect(() => {
    saveState(state);
  }, [state.articles, state.starredIds, state.recentIds, state.videos]);

  const getCategoryById = (id: string) => state.categories.find(c => c.id === id);
  const getUserById = (id: string) => state.users.find(u => u.id === id);
  const getArticleById = (id: string) => state.articles.find(a => a.id === id);
  const currentUser = state.users.find(u => u.id === state.currentUserId)!;

  return (
    <AppContext.Provider value={{ state, dispatch, getCategoryById, getUserById, getArticleById, currentUser }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
