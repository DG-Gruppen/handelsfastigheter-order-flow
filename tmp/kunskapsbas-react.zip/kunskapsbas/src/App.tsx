import { useState } from 'react';
import { AppProvider, useApp } from './store/AppContext';
import Sidebar from './components/layout/Sidebar';
import TopBar from './components/layout/TopBar';
import SearchPalette from './components/search/SearchPalette';
import Toast from './components/ui/Toast';
import HomePage from './pages/HomePage';
import CategoriesPage from './pages/CategoriesPage';
import ArticlePage from './pages/ArticlePage';
import ArticleEditorPage from './pages/ArticleEditorPage';
import VideosPage from './pages/VideosPage';
import StarredPage from './pages/StarredPage';

interface ToastState { message: string; type: 'success' | 'error' | 'info'; id: number }

function AppShell() {
  const { state } = useApp();
  const [toast, setToast] = useState<ToastState | null>(null);
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type, id: Date.now() });
  };

  const renderPage = () => {
    switch (state.currentPage) {
      case 'home': return <HomePage />;
      case 'categories': return <CategoriesPage />;
      case 'article': return <ArticlePage onToast={showToast} />;
      case 'article-new':
      case 'article-edit': return <ArticleEditorPage onToast={showToast} />;
      case 'videos': return <VideosPage onToast={showToast} />;
      case 'starred': return <StarredPage />;
      default: return <HomePage />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-y-auto">
          {renderPage()}
        </main>
      </div>
      <SearchPalette />
      {toast && (
        <Toast
          key={toast.id}
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
