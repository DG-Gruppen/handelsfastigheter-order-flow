export type ArticleStatus = 'draft' | 'published';
export type UserRole = 'admin' | 'editor' | 'viewer';
export type CategoryColor = 'blue' | 'green' | 'amber' | 'red' | 'purple' | 'teal' | 'pink';

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  categoryId: string;
  tags: string[];
  authorId: string;
  status: ArticleStatus;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
  viewCount: number;
  hasVideo?: boolean;
  videoUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  color: CategoryColor;
  parentId: string | null;
}

export interface User {
  id: string;
  name: string;
  initials: string;
  email: string;
  role: UserRole;
  avatarColor: string;
}

export interface VideoLesson {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  url: string;
  thumbnailColor: string;
  duration: string;
  level: 'Grundnivå' | 'Mellannivå' | 'Avancerad' | 'Alla nivåer';
  viewCount: number;
  createdAt: string;
  authorId: string;
}

export type Page =
  | 'home'
  | 'categories'
  | 'article'
  | 'article-edit'
  | 'article-new'
  | 'videos'
  | 'starred'
  | 'admin';
