import { useState, useEffect, useRef } from 'react';
import { useApp } from '../../store/AppContext';
import { Article } from '../../types';
import { slugId, getYouTubeEmbedId, getVimeoEmbedId } from '../../utils';

interface Props {
  onToast: (msg: string, type?: 'success' | 'error') => void;
}

export default function ArticleEditorPage({ onToast }: Props) {
  const { state, dispatch, getArticleById } = useApp();
  const isEdit = state.currentPage === 'article-edit';
  const existing = isEdit && state.currentArticleId ? getArticleById(state.currentArticleId) : null;

  const [title, setTitle] = useState(existing?.title ?? '');
  const [content, setContent] = useState(existing?.content?.replace(/<[^>]+>/g, '') ?? '');
  const [categoryId, setCategoryId] = useState(existing?.categoryId ?? '');
  const [tags, setTags] = useState(existing?.tags.join(', ') ?? '');
  const [status, setStatus] = useState<'draft' | 'published'>(existing?.status ?? 'draft');
  const [videoUrl, setVideoUrl] = useState('');
  const [showVideoBar, setShowVideoBar] = useState(false);
  const [autosave, setAutosave] = useState<'idle' | 'saving' | 'saved'>('idle');
  const autosaveRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (existing) {
      setTitle(existing.title);
      setContent(existing.content.replace(/<[^>]+>/g, ''));
      setCategoryId(existing.categoryId);
      setTags(existing.tags.join(', '));
      setStatus(existing.status);
    }
  }, [existing?.id]);

  const triggerAutosave = () => {
    setAutosave('saving');
    clearTimeout(autosaveRef.current);
    autosaveRef.current = setTimeout(() => setAutosave('saved'), 1400);
  };

  const buildHtml = (raw: string): string => {
    return raw
      .split('\n')
      .map(line => {
        if (line.startsWith('## ')) return `<h2>${line.slice(3)}</h2>`;
        if (line.startsWith('### ')) return `<h3>${line.slice(4)}</h3>`;
        if (line.startsWith('- ')) return `<li>${line.slice(2)}</li>`;
        if (line.startsWith('> ')) return `<blockquote>${line.slice(2)}</blockquote>`;
        if (line.startsWith('```')) return line === '```' ? '' : `<pre><code>${line.slice(3)}</code></pre>`;
        if (line.trim() === '') return '';
        return `<p>${line}</p>`;
      })
      .join('\n');
  };

  const insertText = (before: string, after = '') => {
    const ta = document.getElementById('editor-textarea') as HTMLTextAreaElement;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const selected = content.slice(start, end);
    const newContent = content.slice(0, start) + before + selected + after + content.slice(end);
    setContent(newContent);
    setTimeout(() => { ta.focus(); ta.selectionStart = start + before.length; ta.selectionEnd = start + before.length + selected.length; }, 0);
    triggerAutosave();
  };

  const handleInsertVideo = () => {
    if (!videoUrl.trim()) return;
    const ytId = getYouTubeEmbedId(videoUrl);
    const vimeoId = getVimeoEmbedId(videoUrl);
    const embedLine = ytId
      ? `\n[VIDEO:https://www.youtube.com/embed/${ytId}]\n`
      : vimeoId
      ? `\n[VIDEO:https://player.vimeo.com/video/${vimeoId}]\n`
      : `\n[VIDEO:${videoUrl}]\n`;
    setContent(c => c + embedLine);
    setShowVideoBar(false);
    setVideoUrl('');
    onToast('Video infogad i artikeln');
    triggerAutosave();
  };

  const handleSave = (publishStatus: 'draft' | 'published') => {
    if (!title.trim()) { onToast('Ange en rubrik!', 'error'); return; }
    if (!content.trim()) { onToast('Skriv lite innehåll!', 'error'); return; }
    if (!categoryId) { onToast('Välj en kategori!', 'error'); return; }

    const now = new Date().toISOString();
    const tagList = tags.split(',').map(t => t.trim()).filter(Boolean);
    const htmlContent = buildHtml(content);

    if (isEdit && existing) {
      const updated: Article = { ...existing, title, content: htmlContent, categoryId, tags: tagList, status: publishStatus, updatedAt: now };
      dispatch({ type: 'UPDATE_ARTICLE', article: updated });
      onToast(publishStatus === 'published' ? 'Artikel uppdaterad och publicerad!' : 'Utkast sparat!');
      dispatch({ type: 'VIEW_ARTICLE', id: existing.id });
    } else {
      const article: Article = {
        id: slugId(), title, excerpt: content.slice(0, 120) + '...', content: htmlContent,
        categoryId, tags: tagList, authorId: state.currentUserId, status: publishStatus,
        pinned: false, createdAt: now, updatedAt: now, viewCount: 0,
      };
      dispatch({ type: 'ADD_ARTICLE', article });
      onToast(publishStatus === 'published' ? 'Artikel publicerad!' : 'Utkast sparat!');
      dispatch({ type: 'VIEW_ARTICLE', id: article.id });
    }
  };

  return (
    <div className="p-8 max-w-3xl">
      <div className="mb-5">
        <h1 className="text-xl font-semibold text-gray-900">{isEdit ? 'Redigera artikel' : 'Ny artikel'}</h1>
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden">
        {/* Toolbar */}
        <div className="flex items-center gap-1 px-3 py-2 border-b border-gray-100 flex-wrap">
          {[
            { label: <b>B</b>, action: () => insertText('**', '**') },
            { label: <i>I</i>, action: () => insertText('_', '_') },
            { label: 'H2', action: () => insertText('\n## ') },
            { label: 'H3', action: () => insertText('\n### ') },
            { label: '≡', action: () => insertText('\n- ') },
            { label: '1.', action: () => insertText('\n1. ') },
            { label: '❝', action: () => insertText('\n> ') },
            { label: '</>', action: () => insertText('\n```\n', '\n```') },
          ].map((btn, i) => (
            <button
              key={i}
              onClick={btn.action}
              className="w-8 h-7 flex items-center justify-center text-xs text-gray-500 hover:bg-gray-100 hover:text-gray-900 rounded transition-colors font-mono"
            >
              {btn.label}
            </button>
          ))}
          <div className="w-px h-5 bg-gray-200 mx-1" />
          <button
            onClick={() => setShowVideoBar(v => !v)}
            className={`w-8 h-7 flex items-center justify-center text-xs rounded transition-colors ${showVideoBar ? 'bg-amber-100 text-amber-700' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Infoga video"
          >
            🎬
          </button>
          <div className="ml-auto text-xs text-gray-400 flex items-center gap-1">
            {autosave === 'saving' && <span>Sparar...</span>}
            {autosave === 'saved' && <span className="text-emerald-600">✓ Sparat</span>}
          </div>
        </div>

        {/* Video insert bar */}
        {showVideoBar && (
          <div className="px-4 py-2 bg-amber-50 border-b border-amber-100 flex items-center gap-2">
            <input
              type="text"
              value={videoUrl}
              onChange={e => setVideoUrl(e.target.value)}
              placeholder="Klistra in YouTube eller Vimeo URL..."
              className="flex-1 text-sm bg-white border border-amber-200 rounded-lg px-3 py-1.5 outline-none"
              onKeyDown={e => e.key === 'Enter' && handleInsertVideo()}
            />
            <button onClick={handleInsertVideo} className="text-sm bg-gray-900 text-white px-3 py-1.5 rounded-lg hover:bg-gray-700">
              Infoga
            </button>
            <button onClick={() => setShowVideoBar(false)} className="text-gray-400 hover:text-gray-600 px-1">✕</button>
          </div>
        )}

        {/* Title */}
        <textarea
          value={title}
          onChange={e => { setTitle(e.target.value); triggerAutosave(); }}
          placeholder="Artikelrubrik..."
          rows={1}
          className="w-full px-5 pt-5 pb-2 text-xl font-semibold text-gray-900 placeholder-gray-300 outline-none resize-none bg-transparent"
          style={{ fontFamily: 'Georgia, serif' }}
        />

        {/* Body */}
        <textarea
          id="editor-textarea"
          value={content}
          onChange={e => { setContent(e.target.value); triggerAutosave(); }}
          placeholder={`Skriv innehåll här...\n\nTips:\n## Rubrik\n- Punktlista\n> Citat\n\`\`\`\nkodblock\n\`\`\``}
          className="w-full px-5 py-3 text-sm text-gray-800 placeholder-gray-300 outline-none resize-none bg-transparent leading-relaxed min-h-72 font-mono"
        />

        {/* Footer */}
        <div className="flex items-center gap-3 px-4 py-3 border-t border-gray-100 bg-gray-50 flex-wrap">
          <select
            value={categoryId}
            onChange={e => setCategoryId(e.target.value)}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 outline-none"
          >
            <option value="">Välj kategori...</option>
            {state.categories.map(c => (
              <option key={c.id} value={c.id}>{c.icon} {c.name}</option>
            ))}
          </select>
          <input
            value={tags}
            onChange={e => { setTags(e.target.value); triggerAutosave(); }}
            placeholder="Taggar, kommaseparerade"
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 outline-none flex-1 min-w-32"
          />
          <select
            value={status}
            onChange={e => setStatus(e.target.value as 'draft' | 'published')}
            className="text-sm border border-gray-200 rounded-lg px-3 py-1.5 bg-white text-gray-700 outline-none"
          >
            <option value="draft">Utkast</option>
            <option value="published">Publicerad</option>
          </select>
          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={() => handleSave('draft')}
              className="text-sm border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              Spara utkast
            </button>
            <button
              onClick={() => handleSave('published')}
              className="text-sm bg-gray-900 text-white px-4 py-1.5 rounded-lg hover:bg-gray-700 transition-colors"
            >
              Publicera
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
