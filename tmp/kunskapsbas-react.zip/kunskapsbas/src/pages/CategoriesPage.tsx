import { useState } from 'react';
import { useApp } from '../../store/AppContext';
import { COLOR_MAP, relativeTime, readTime } from '../../utils';
import CategoryBadge from '../ui/CategoryBadge';

export default function CategoriesPage() {
  const { state, dispatch, getCategoryById, getUserById } = useApp();
  const [selectedCat, setSelectedCat] = useState<string | null>(null);
  const [sort, setSort] = useState<'newest' | 'oldest' | 'az' | 'views'>('newest');

  const published = state.articles.filter(a => a.status === 'published');

  const catArticles = selectedCat
    ? published.filter(a => a.categoryId === selectedCat)
    : published;

  const sorted = [...catArticles].sort((a, b) => {
    if (sort === 'newest') return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    if (sort === 'oldest') return new Date(a.updatedAt).getTime() - new Date(b.updatedAt).getTime();
    if (sort === 'az') return a.title.localeCompare(b.title, 'sv');
    return b.viewCount - a.viewCount;
  });

  return (
    <div className="p-8 max-w-5xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 mb-1">Kategorier</h1>
        <p className="text-sm text-gray-500">Bläddra bland alla kunskapsområden</p>
      </div>

      {/* Category cards */}
      <div className="grid grid-cols-3 gap-3 mb-8">
        {state.categories.map(cat => {
          const colors = COLOR_MAP[cat.color];
          const count = published.filter(a => a.categoryId === cat.id).length;
          const active = selectedCat === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(active ? null : cat.id)}
              className={`text-left p-4 rounded-xl border transition-all ${
                active
                  ? `${colors.bg} ${colors.border} border-2 shadow-sm`
                  : `bg-white border-gray-100 hover:border-gray-200 hover:shadow-sm`
              }`}
            >
              <div className="text-2xl mb-2">{cat.icon}</div>
              <div className="font-medium text-sm text-gray-900 mb-1">{cat.name}</div>
              <div className="text-xs text-gray-500 line-clamp-2 mb-2">{cat.description}</div>
              <div className={`text-xs font-medium ${active ? colors.text : 'text-gray-400'}`}>{count} artiklar</div>
            </button>
          );
        })}
      </div>

      {/* Article list */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-semibold text-gray-700">
          {selectedCat
            ? `${state.categories.find(c => c.id === selectedCat)?.name} — ${sorted.length} artiklar`
            : `Alla artiklar — ${sorted.length}`}
        </h2>
        <select
          value={sort}
          onChange={e => setSort(e.target.value as typeof sort)}
          className="text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-600 bg-white outline-none"
        >
          <option value="newest">Nyaste först</option>
          <option value="oldest">Äldsta först</option>
          <option value="az">A–Ö</option>
          <option value="views">Mest visade</option>
        </select>
      </div>

      <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
        {sorted.length === 0 && (
          <div className="p-8 text-center text-sm text-gray-400">
            Inga artiklar i denna kategori ännu.{' '}
            <button onClick={() => dispatch({ type: 'NAVIGATE', page: 'article-new' })} className="text-blue-600 hover:underline">
              Skapa den första →
            </button>
          </div>
        )}
        {sorted.map((article, i) => {
          const cat = getCategoryById(article.categoryId);
          const isStarred = state.starredIds.includes(article.id);
          return (
            <button
              key={article.id}
              onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: article.id })}
              className={`w-full flex items-start gap-3 px-4 py-3.5 text-left hover:bg-gray-50 transition-colors ${i > 0 ? 'border-t border-gray-50' : ''}`}
            >
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm flex-shrink-0 mt-0.5 ${cat ? COLOR_MAP[cat.color].bg : 'bg-gray-100'}`}>
                📄
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start gap-2">
                  <div className="text-sm font-medium text-gray-900 truncate">{article.title}</div>
                  {isStarred && <span className="text-amber-400 text-xs flex-shrink-0 mt-0.5">★</span>}
                </div>
                <div className="text-xs text-gray-400 line-clamp-1 mt-0.5">{article.excerpt}</div>
                <div className="flex items-center gap-2 mt-1.5">
                  {article.tags.slice(0, 3).map(tag => (
                    <span key={tag} className="text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">{tag}</span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                {cat && <CategoryBadge category={cat} />}
                <div className="text-xs text-gray-400">{relativeTime(article.updatedAt)}</div>
                <div className="text-xs text-gray-400">{readTime(article.content)}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
