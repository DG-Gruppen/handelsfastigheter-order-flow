import { useApp } from '../../store/AppContext';
import CategoryBadge from '../ui/CategoryBadge';
import { relativeTime, readTime, COLOR_MAP } from '../../utils';

export default function HomePage() {
  const { state, dispatch, getCategoryById, getUserById } = useApp();
  const { articles, videos, categories, starredIds } = state;

  const published = articles.filter(a => a.status === 'published');
  const pinned = published.filter(a => a.pinned).slice(0, 4);
  const recent = [...published].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()).slice(0, 6);
  const recentWeek = published.filter(a => Date.now() - new Date(a.updatedAt).getTime() < 7 * 86400000).length;

  return (
    <div className="p-8 max-w-5xl">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Artiklar totalt', value: published.length, sub: 'publicerade' },
          { label: 'Kategorier', value: categories.length, sub: 'aktiva' },
          { label: 'Senaste 7 dagarna', value: recentWeek, sub: 'uppdaterade' },
          { label: 'Videoutbildningar', value: videos.length, sub: 'tillgängliga' },
        ].map(stat => (
          <div key={stat.label} className="bg-gray-50 rounded-xl p-4">
            <div className="text-xs text-gray-500 mb-1">{stat.label}</div>
            <div className="text-2xl font-semibold text-gray-900">{stat.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{stat.sub}</div>
          </div>
        ))}
      </div>

      {/* Pinned articles */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-gray-900">Utvalda artiklar</h2>
        <button onClick={() => dispatch({ type: 'NAVIGATE', page: 'categories' })} className="text-sm text-gray-500 hover:text-gray-800">
          Se alla →
        </button>
      </div>
      <div className="grid grid-cols-2 gap-3 mb-8">
        {pinned.map(article => {
          const cat = getCategoryById(article.categoryId);
          const colors = cat ? COLOR_MAP[cat.color] : null;
          return (
            <button
              key={article.id}
              onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: article.id })}
              className="text-left bg-white border border-gray-100 rounded-xl p-4 hover:border-gray-200 hover:shadow-sm transition-all group"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <h3 className="text-sm font-medium text-gray-900 leading-snug group-hover:text-gray-700">{article.title}</h3>
                {cat && <CategoryBadge category={cat} />}
              </div>
              <p className="text-xs text-gray-500 line-clamp-2 mb-3">{article.excerpt}</p>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <span>{getUserById(article.authorId)?.name}</span>
                <span>·</span>
                <span>{relativeTime(article.updatedAt)}</span>
                <span>·</span>
                <span>{readTime(article.content)}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Category quick-links */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-gray-900">Kategorier</h2>
      </div>
      <div className="grid grid-cols-5 gap-3 mb-8">
        {categories.map(cat => {
          const colors = COLOR_MAP[cat.color];
          const count = published.filter(a => a.categoryId === cat.id).length;
          return (
            <button
              key={cat.id}
              onClick={() => dispatch({ type: 'NAVIGATE', page: 'categories' })}
              className={`text-left p-3 rounded-xl border transition-colors hover:shadow-sm ${colors.bg} ${colors.border} border`}
            >
              <div className="text-xl mb-1.5">{cat.icon}</div>
              <div className={`text-xs font-semibold ${colors.text} leading-tight mb-0.5`}>{cat.name}</div>
              <div className={`text-xs ${colors.text} opacity-70`}>{count} artiklar</div>
            </button>
          );
        })}
      </div>

      {/* Recently updated */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-gray-900">Senast uppdaterat</h2>
      </div>
      <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
        {recent.map((article, i) => {
          const cat = getCategoryById(article.categoryId);
          const isStarred = starredIds.includes(article.id);
          return (
            <button
              key={article.id}
              onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: article.id })}
              className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors ${i > 0 ? 'border-t border-gray-50' : ''}`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${cat ? COLOR_MAP[cat.color].bg : 'bg-gray-100'}`}>
                📄
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-gray-900 truncate">{article.title}</div>
                <div className="text-xs text-gray-400">{cat?.name}</div>
              </div>
              {cat && <CategoryBadge category={cat} />}
              <span className="text-xs text-gray-400 flex-shrink-0">{relativeTime(article.updatedAt)}</span>
              {isStarred && <span className="text-amber-400 text-xs">★</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}
