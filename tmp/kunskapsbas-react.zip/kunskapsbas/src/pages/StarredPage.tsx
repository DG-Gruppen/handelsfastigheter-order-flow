import { useApp } from '../../store/AppContext';
import { relativeTime, readTime, COLOR_MAP } from '../../utils';
import CategoryBadge from '../ui/CategoryBadge';

export default function StarredPage() {
  const { state, dispatch, getCategoryById } = useApp();
  const starred = state.articles.filter(a => state.starredIds.includes(a.id));

  return (
    <div className="p-8 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 mb-1">Stjärnmärkta artiklar</h1>
        <p className="text-sm text-gray-500">Dina sparade artiklar för snabb åtkomst</p>
      </div>

      {starred.length === 0 ? (
        <div className="bg-white border border-gray-100 rounded-xl p-10 text-center">
          <div className="text-3xl mb-3">☆</div>
          <div className="text-sm font-medium text-gray-600 mb-1">Inga stjärnmärkta artiklar</div>
          <div className="text-xs text-gray-400">Klicka på ★ i en artikel för att spara den här.</div>
        </div>
      ) : (
        <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
          {starred.map((article, i) => {
            const cat = getCategoryById(article.categoryId);
            return (
              <button
                key={article.id}
                onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: article.id })}
                className={`w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-gray-50 transition-colors ${i > 0 ? 'border-t border-gray-50' : ''}`}
              >
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm flex-shrink-0 ${cat ? COLOR_MAP[cat.color].bg : 'bg-gray-100'}`}>
                  ★
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-900 truncate">{article.title}</div>
                  <div className="text-xs text-gray-400 line-clamp-1 mt-0.5">{article.excerpt}</div>
                </div>
                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  {cat && <CategoryBadge category={cat} />}
                  <span className="text-xs text-gray-400">{relativeTime(article.updatedAt)}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
