import { useState } from 'react';
import { useApp } from '../../store/AppContext';
import { VideoLesson } from '../../types';
import { COLOR_MAP, slugId, getYouTubeEmbedId, getVimeoEmbedId } from '../../utils';

interface Props {
  onToast: (msg: string) => void;
}

export default function VideosPage({ onToast }: Props) {
  const { state, dispatch, getCategoryById } = useApp();
  const [activeVideo, setActiveVideo] = useState<VideoLesson | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newCat, setNewCat] = useState('');
  const [newLevel, setNewLevel] = useState<VideoLesson['level']>('Alla nivåer');

  const getEmbedUrl = (url: string): string => {
    const ytId = getYouTubeEmbedId(url);
    if (ytId) return `https://www.youtube.com/embed/${ytId}`;
    const vimeoId = getVimeoEmbedId(url);
    if (vimeoId) return `https://player.vimeo.com/video/${vimeoId}`;
    return url;
  };

  const handleAdd = () => {
    if (!newTitle.trim() || !newUrl.trim()) { onToast('Fyll i titel och URL!'); return; }
    const video: VideoLesson = {
      id: slugId(), title: newTitle, description: '', categoryId: newCat || 'it',
      url: getEmbedUrl(newUrl), thumbnailColor: 'linear-gradient(135deg, #374151 0%, #6B7280 100%)',
      duration: '—', level: newLevel, viewCount: 0, createdAt: new Date().toISOString(), authorId: state.currentUserId,
    };
    dispatch({ type: 'ADD_VIDEO', video });
    setNewTitle(''); setNewUrl(''); setNewCat(''); setShowAddForm(false);
    onToast('Video tillagd!');
  };

  return (
    <div className="p-8 max-w-4xl">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 mb-1">Videoutbildningar</h1>
          <p className="text-sm text-gray-500">Kurser och instruktionsvideor för hela teamet</p>
        </div>
        <button
          onClick={() => setShowAddForm(v => !v)}
          className="flex items-center gap-1.5 text-sm bg-gray-900 text-white px-3 py-2 rounded-xl hover:bg-gray-700 transition-colors"
        >
          + Lägg till video
        </button>
      </div>

      {/* Add form */}
      {showAddForm && (
        <div className="bg-white border border-gray-100 rounded-xl p-5 mb-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">Lägg till videoutbildning</h3>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <label className="text-xs text-gray-500 block mb-1">Titel</label>
              <input
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="T.ex. Intro till säkerhetspolicy"
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 outline-none"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 block mb-1">Kategori</label>
              <select value={newCat} onChange={e => setNewCat(e.target.value)} className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 outline-none bg-white">
                <option value="">Välj kategori...</option>
                {state.categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
              </select>
            </div>
          </div>
          <div className="mb-3">
            <label className="text-xs text-gray-500 block mb-1">YouTube / Vimeo URL</label>
            <input
              value={newUrl}
              onChange={e => setNewUrl(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=..."
              className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 outline-none"
            />
          </div>
          <div className="flex items-center gap-3">
            <select value={newLevel} onChange={e => setNewLevel(e.target.value as VideoLesson['level'])} className="text-sm border border-gray-200 rounded-lg px-3 py-2 outline-none bg-white">
              <option>Grundnivå</option>
              <option>Mellannivå</option>
              <option>Avancerad</option>
              <option>Alla nivåer</option>
            </select>
            <button onClick={handleAdd} className="text-sm bg-gray-900 text-white px-4 py-2 rounded-lg hover:bg-gray-700">Spara</button>
            <button onClick={() => setShowAddForm(false)} className="text-sm text-gray-500 hover:text-gray-800 px-2 py-2">Avbryt</button>
          </div>
        </div>
      )}

      {/* Active player */}
      {activeVideo && (
        <div className="bg-white border border-gray-100 rounded-xl overflow-hidden mb-6">
          <div style={{ aspectRatio: '16/9', background: '#000' }}>
            <iframe
              src={activeVideo.url.includes('embed') ? activeVideo.url : getEmbedUrl(activeVideo.url)}
              className="w-full h-full"
              frameBorder="0"
              allowFullScreen
              title={activeVideo.title}
            />
          </div>
          <div className="px-5 py-4 flex items-start justify-between">
            <div>
              <h2 className="font-semibold text-gray-900 text-base mb-1">{activeVideo.title}</h2>
              <div className="text-sm text-gray-400">{activeVideo.duration} · {activeVideo.level} · {activeVideo.viewCount.toLocaleString('sv')} visningar</div>
            </div>
            <button onClick={() => setActiveVideo(null)} className="text-gray-400 hover:text-gray-700 text-lg">✕</button>
          </div>
        </div>
      )}

      {/* Video grid */}
      <div className="grid grid-cols-2 gap-4">
        {state.videos.map(video => {
          const cat = getCategoryById(video.categoryId);
          const isActive = activeVideo?.id === video.id;
          return (
            <div
              key={video.id}
              onClick={() => setActiveVideo(isActive ? null : video)}
              className={`bg-white border rounded-xl overflow-hidden cursor-pointer transition-all hover:shadow-md group ${isActive ? 'border-gray-900' : 'border-gray-100 hover:border-gray-200'}`}
            >
              <div className="relative" style={{ aspectRatio: '16/9', background: video.thumbnailColor }}>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-transform group-hover:scale-110 ${isActive ? 'bg-white' : 'bg-black/50'}`}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill={isActive ? '#111' : 'white'}>
                      <polygon points="5 3 19 12 5 21 5 3" />
                    </svg>
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-1.5 py-0.5 rounded">
                  {video.duration}
                </div>
              </div>
              <div className="p-3">
                <div className="text-sm font-medium text-gray-900 mb-1 line-clamp-2">{video.title}</div>
                <div className="flex items-center gap-2">
                  {cat && (
                    <span className={`text-xs px-1.5 py-0.5 rounded-full ${COLOR_MAP[cat.color].badge} ${COLOR_MAP[cat.color].badgeText}`}>
                      {cat.icon} {cat.name}
                    </span>
                  )}
                  <span className="text-xs text-gray-400 ml-auto">{video.level}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
