import { useApp } from '../../store/AppContext';
import { readTime, relativeTime, COLOR_MAP } from '../../utils';
import CategoryBadge from '../ui/CategoryBadge';

interface Props {
  onToast: (msg: string) => void;
}

export default function ArticlePage({ onToast }: Props) {
  const { state, dispatch, getArticleById, getCategoryById, getUserById } = useApp();
  const article = state.currentArticleId ? getArticleById(state.currentArticleId) : null;

  if (!article) {
    return (
      <div className="p-8 text-sm text-gray-400">Artikel hittades inte.</div>
    );
  }

  const cat = getCategoryById(article.categoryId);
  const author = getUserById(article.authorId);
  const isStarred = state.starredIds.includes(article.id);
  const related = state.articles
    .filter(a => a.id !== article.id && a.categoryId === article.categoryId && a.status === 'published')
    .slice(0, 3);

  return (
    <div className="p-8 max-w-3xl">
      {/* Back */}
      <button
        onClick={() => dispatch({ type: 'NAVIGATE', page: 'categories' })}
        className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-700 mb-5 transition-colors"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="m15 18-6-6 6-6" />
        </svg>
        Tillbaka
      </button>

      {/* Tags */}
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        {article.tags.map(tag => (
          <span key={tag} className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{tag}</span>
        ))}
        <button
          onClick={() => { dispatch({ type: 'TOGGLE_STAR', id: article.id }); onToast(isStarred ? 'Stjärnmärkning borttagen' : 'Artikel stjärnmärkt!'); }}
          className="ml-auto text-xl leading-none hover:scale-110 transition-transform"
          title={isStarred ? 'Ta bort stjärnmärkning' : 'Stjärnmärk artikel'}
        >
          {isStarred ? '★' : '☆'}
        </button>
      </div>

      {/* Title */}
      <h1 className="text-3xl font-semibold text-gray-900 leading-tight mb-5" style={{ fontFamily: 'Georgia, serif' }}>
        {article.title}
      </h1>

      {/* Meta bar */}
      <div className="flex items-center gap-4 py-3 border-t border-b border-gray-100 mb-7 flex-wrap">
        <div className="flex items-center gap-2">
          <div
            className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-medium"
            style={{ background: author?.avatarColor || '#6B7280' }}
          >
            {author?.initials}
          </div>
          <span className="text-sm text-gray-600">{author?.name}</span>
        </div>
        <span className="text-xs text-gray-400">{relativeTime(article.updatedAt)}</span>
        <span className="text-xs text-gray-400">⏱ {readTime(article.content)}</span>
        {cat && <CategoryBadge category={cat} size="md" />}
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={() => { navigator.clipboard.writeText(window.location.href).catch(() => {}); onToast('Länk kopierad!'); }}
            className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 border border-gray-200 px-2.5 py-1.5 rounded-lg transition-colors"
          >
            🔗 Kopiera länk
          </button>
          <button
            onClick={() => dispatch({ type: 'NAVIGATE', page: 'article-edit', articleId: article.id })}
            className="flex items-center gap-1.5 text-xs text-white bg-gray-900 hover:bg-gray-700 px-2.5 py-1.5 rounded-lg transition-colors"
          >
            ✏️ Redigera
          </button>
        </div>
      </div>

      {/* Content */}
      <div
        className="prose prose-sm max-w-none text-gray-800 leading-relaxed article-body"
        dangerouslySetInnerHTML={{ __html: article.content }}
      />

      {/* Video embed */}
      {article.videoUrl && (
        <div className="mt-6 rounded-xl overflow-hidden border border-gray-100" style={{ aspectRatio: '16/9' }}>
          <iframe
            src={article.videoUrl}
            className="w-full h-full"
            frameBorder="0"
            allowFullScreen
            title={article.title}
          />
        </div>
      )}

      {/* Related */}
      {related.length > 0 && (
        <div className="mt-10 pt-6 border-t border-gray-100">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Relaterade artiklar</h3>
          <div className="space-y-2">
            {related.map(rel => {
              const relCat = getCategoryById(rel.categoryId);
              return (
                <button
                  key={rel.id}
                  onClick={() => dispatch({ type: 'VIEW_ARTICLE', id: rel.id })}
                  className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors text-left"
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${relCat ? COLOR_MAP[relCat.color].bg : 'bg-gray-200'}`}>📄</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-900 truncate">{rel.title}</div>
                    <div className="text-xs text-gray-400">{readTime(rel.content)}</div>
                  </div>
                  {relCat && <CategoryBadge category={relCat} />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
