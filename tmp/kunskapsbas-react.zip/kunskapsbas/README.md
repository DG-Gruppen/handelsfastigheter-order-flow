# Kunskapsbas — Intern Wiki

## Snabbstart i Lovable

1. Skapa ett nytt Lovable-projekt
2. Ladda upp hela denna mapp (eller klistra in filerna en efter en)
3. Lovable installerar dependencies automatiskt och startar dev-servern

## Projektstruktur

```
src/
  types/index.ts          — TypeScript-interfaces
  data/seedData.ts        — Exempeldata (artiklar, kategorier, users, videos)
  store/AppContext.tsx     — Global state med useReducer + localStorage
  utils/index.ts          — Hjälpfunktioner (sök, datum, färger)
  components/
    layout/Sidebar.tsx    — Kollapsbar sidebar med kategoriträd
    layout/TopBar.tsx     — Topbar med brödsmulor och actions
    search/SearchPalette  — ⌘K sökning (overlay)
    ui/CategoryBadge.tsx  — Färgkodad kategoribadge
    ui/Toast.tsx          — Notifieringstoast
  pages/
    HomePage.tsx          — Dashboard med stats, utvalda artiklar, kategorier
    CategoriesPage.tsx    — Kategoribläddring + artikellista med sortering
    ArticlePage.tsx       — Artikelvisare med relaterade artiklar
    ArticleEditorPage.tsx — Editor (ny + redigera) med verktygsfält
    VideosPage.tsx        — Videogalleri med YouTube/Vimeo-inbäddning
    StarredPage.tsx       — Stjärnmärkta artiklar
  App.tsx                 — Root med routing och toast-hantering
  main.tsx                — Entry point
  index.css               — Tailwind + article body-stilar
```

## Funktioner

- **Artiklar** — Skapa, redigera, publicera/utkast, taggar, kategorier
- **Videoutbildningar** — YouTube/Vimeo-inbäddning, lägg till via URL
- **Sökning** — ⌘K command palette med fuzzy-sökning
- **Stjärnmärkning** — Spara favoriter
- **localStorage** — All data persisteras lokalt
- **Färgkodade kategorier** — Blå (IT), Grön (HR), Amber (Rutiner), Röd (Säkerhet), Lila (Produkter)

## Utöka med Lovable

Säg till Lovable att lägga till:
- `shadcn/ui` för Dialog, Dropdown etc.
- `TipTap` för riktig rich text-editor
- `React Router DOM` för URL-routing
- Backend/Supabase för fleruser-stöd
